# LLM Fine-tuning Resources

Collection of resources I personally use for finetuning LLMs using Unsloth.

Unsloth: https://github.com/unslothai/unsloth





