https://huggingface.co/spaces/ggml-org/gguf-my-repo
-> create quantized gguf of repo

https://huggingface.co/spaces/ggml-org/gguf-my-lora
-> create gguf of lora